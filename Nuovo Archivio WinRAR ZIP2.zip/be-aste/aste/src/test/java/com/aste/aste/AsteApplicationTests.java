package com.aste.aste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsteApplicationTests {

	@Test
	void contextLoads() {
	}

}
