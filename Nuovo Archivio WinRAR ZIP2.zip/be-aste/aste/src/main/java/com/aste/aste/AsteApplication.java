package com.aste.aste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsteApplication.class, args);
	}

}
