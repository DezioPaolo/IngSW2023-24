package com.aste.aste.service;

import com.aste.aste.enums.TipologiaAccount;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.databind.util.Converter;

public class StringToEnumConverter implements Converter<String, TipologiaAccount> {

    @Override
    public TipologiaAccount convert(String value) {
        return TipologiaAccount.valueOf(value);
    }

    @Override
    public JavaType getInputType(TypeFactory typeFactory) {
      
        throw new UnsupportedOperationException("Unimplemented method 'getInputType'");
    }

    @Override
    public JavaType getOutputType(TypeFactory typeFactory) {
        
        throw new UnsupportedOperationException("Unimplemented method 'getOutputType'");
    }
}

