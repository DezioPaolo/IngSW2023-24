package com.aste.aste.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aste.aste.domain.AstaRibasso;
import com.aste.aste.service.AstaRibassoService;

@RestController
@RequestMapping("/DietiDials24/AstaRibasso")
public class AstaRibassoController {
    @Autowired
    AstaRibassoService astaRibassoService;

    @GetMapping(path = "/")
    ResponseEntity<?> findAll() {
        return new ResponseEntity<>(astaRibassoService.findAll(), HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    ResponseEntity<AstaRibasso> findById(@PathVariable Integer id) {
        AstaRibasso astaRibasso = astaRibassoService.findById(id);
        return new ResponseEntity<AstaRibasso>(astaRibasso, HttpStatus.OK);
    }

    @PostMapping
    ResponseEntity<AstaRibasso> save(@RequestBody AstaRibasso astaRibasso) {
        AstaRibasso astaRibasso1 = astaRibassoService.save(astaRibasso);
        return new ResponseEntity<>(astaRibasso1, HttpStatus.OK);
    }

    @DeleteMapping(path="/{id}")
    ResponseEntity<Object> delete(@PathVariable Integer id) {
        String message = "L'asta al ribasso con id "+id+" è stato cancellato con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        astaRibassoService.deleteById(id);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

    @PutMapping(path = "/{id}")
    ResponseEntity<AstaRibasso> update(@PathVariable Integer id, @RequestBody AstaRibasso astaRibasso) {
        AstaRibasso updatedAstaRibasso = astaRibassoService.update(id, astaRibasso);
        if (updatedAstaRibasso != null) {
            return new ResponseEntity<>(updatedAstaRibasso, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping(path ="/")
    ResponseEntity<?> deleteAll(){
        astaRibassoService.deleteAll();
        String message = "Tutte le aste al ribasso sono state cancellate con successo!"; 
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }
}