package com.aste.aste.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aste.aste.domain.AstaRibasso;

@Repository
public interface AstaRibassoRepository extends JpaRepository<AstaRibasso,Integer>{
    
}
