package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.AstaRibasso;
import com.aste.aste.repository.AstaRibassoRepository;

@Service
public class AstaRibassoService {
    @Autowired
    AstaRibassoRepository astaRibassoRepository;

    public List<AstaRibasso> findAll(){
        return astaRibassoRepository.findAll();
    }
    
    public AstaRibasso findById(Integer id){
        return astaRibassoRepository.findById(id).orElse(null);
    }

    public AstaRibasso save(AstaRibasso astaRibasso){
        return astaRibassoRepository.save(astaRibasso);
    }

    public void deleteById(Integer id){
        astaRibassoRepository.deleteById(id);
    }

    public AstaRibasso update(Integer id, AstaRibasso astaRibasso){
        AstaRibasso astaRibasso1 = astaRibassoRepository.findById(id).orElse(null);
        if (astaRibasso1 != null){
            astaRibasso1.setTitolo(astaRibasso.getTitolo());
            astaRibasso1.setDescrizione(astaRibasso.getDescrizione());
            astaRibasso1.setFotografia(astaRibasso.getFotografia());
            astaRibasso1.setIdcategoria(astaRibasso.getIdcategoria());
            astaRibasso1.setPrezzoiniziale(astaRibasso.getPrezzoiniziale());
            astaRibasso1.setTimer(astaRibasso.getTimer());
            astaRibasso1.setImporto(astaRibasso.getImporto());
            astaRibasso1.setPrezzominimo(astaRibasso.getPrezzominimo());
            astaRibasso1.setStato(astaRibasso.getStato());
            astaRibasso1.setIdvenditore(astaRibasso.getIdvenditore());
            astaRibasso1.setIdofferta(astaRibasso.getIdofferta());
            return astaRibassoRepository.save(astaRibasso1);
        }
        return null;
    }

    public void deleteAll(){
        astaRibassoRepository.deleteAll();
    }
}
