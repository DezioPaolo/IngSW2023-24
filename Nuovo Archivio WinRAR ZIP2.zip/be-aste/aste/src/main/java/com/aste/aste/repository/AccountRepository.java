package com.aste.aste.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aste.aste.domain.Account;
import com.aste.aste.enums.TipologiaAccount;

@Repository
public interface AccountRepository extends JpaRepository<Account,Integer> {
     List<Account> findByTipologia(TipologiaAccount tipologia);
}
