package com.aste.aste.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aste.aste.domain.OffertaAstaRibasso;
import com.aste.aste.service.OffertaAstaRibassoService;

@RestController
@RequestMapping("/DietiDials24/AstaRibasso/Offerte")
public class OffertaAstaRibassoController {
    @Autowired
    OffertaAstaRibassoService offertaAstaRibassoService;
    
    @GetMapping(path = "/")
    ResponseEntity<?> findAll() {
        return new ResponseEntity<>(offertaAstaRibassoService.findAll(), HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    ResponseEntity<OffertaAstaRibasso> findById(@PathVariable Integer id) {
        OffertaAstaRibasso offertaAstaRibasso = offertaAstaRibassoService.findById(id);
        return new ResponseEntity<OffertaAstaRibasso>(offertaAstaRibasso, HttpStatus.OK);
    }

    @PostMapping
    ResponseEntity<OffertaAstaRibasso> save(@RequestBody OffertaAstaRibasso offertaAstaRibasso) {
        OffertaAstaRibasso offertaAstaRibasso1 = offertaAstaRibassoService.save(offertaAstaRibasso);
        return new ResponseEntity<>(offertaAstaRibasso1, HttpStatus.OK);
    }

    @DeleteMapping(path="/{id}")
    ResponseEntity<Object> delete(@PathVariable Integer id) {
        String message = "L'offerta per l'asta al ribasso con id "+id+" è stato cancellato con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        offertaAstaRibassoService.deleteById(id);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

    @PutMapping(path = "/{id}")
    ResponseEntity<OffertaAstaRibasso> update(@PathVariable Integer id, @RequestBody OffertaAstaRibasso offertaAstaRibasso) {
        OffertaAstaRibasso updatedOffertaAstaRibasso = offertaAstaRibassoService.update(id, offertaAstaRibasso);
        if (updatedOffertaAstaRibasso != null) {
            return new ResponseEntity<>(updatedOffertaAstaRibasso, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping(path ="/")
    ResponseEntity<?> deleteAll(){
        offertaAstaRibassoService.deleteAll();
        String message = "Tutte le offerte delle aste al ribasso sono state cancellate con successo!"; 
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }
}
