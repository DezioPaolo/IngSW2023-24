package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.Categoria;
import com.aste.aste.repository.CategoriaRepository;

@Service
public class CategoriaService {
    @Autowired
    CategoriaRepository categoriaRepository;

    public List<Categoria> findAll(){
        return categoriaRepository.findAll();
    }
    
    public Categoria findById(Integer id){
        return categoriaRepository.findById(id).orElse(null);
    }

    public Categoria save(Categoria categoria){
        return categoriaRepository.save(categoria);
    }

    public void deleteById(Integer id){
        categoriaRepository.deleteById(id);
    }

    public Categoria update(Integer id, Categoria categoria){
        Categoria categoria1 = categoriaRepository.findById(id).orElse(null);
        if (categoria1 != null){
            categoria1.setNome(categoria.getNome());
            return categoriaRepository.save(categoria1);
        }
        return null;
    }

    public void deleteAll(){
        categoriaRepository.deleteAll();
    }
}
