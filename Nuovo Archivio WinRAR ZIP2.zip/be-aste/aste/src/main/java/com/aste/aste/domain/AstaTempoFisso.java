package com.aste.aste.domain;

import java.time.LocalDateTime;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.aste.aste.enums.StatoAsta;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="ASTATEMPOFISSO")
public class AstaTempoFisso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String titolo;
    private String descrizione;
    private String fotografia;
    private Integer idcategoria;
    private LocalDateTime datascadenza;
    private Float sogliaminima;
    @Enumerated(EnumType.STRING)
    private StatoAsta stato;
    private Integer idvenditore;
    private Integer idofferta;
}
