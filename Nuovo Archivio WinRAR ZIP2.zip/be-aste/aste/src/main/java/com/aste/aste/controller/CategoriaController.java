package com.aste.aste.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aste.aste.domain.Categoria;
import com.aste.aste.service.CategoriaService;

@RestController
@RequestMapping("/DietiDials24/Categoria")
public class CategoriaController {
    @Autowired
    CategoriaService categoriaService;
    
    @GetMapping(path = "/")
    ResponseEntity<?> findAll() {
        return new ResponseEntity<>(categoriaService.findAll(), HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    ResponseEntity<Categoria> findById(@PathVariable Integer id) {
        Categoria categoria = categoriaService.findById(id);
        return new ResponseEntity<Categoria>(categoria, HttpStatus.OK);
    }

    @PostMapping
    ResponseEntity<Categoria> save(@RequestBody Categoria categoria) {
        Categoria categoria1 = categoriaService.save(categoria);
        return new ResponseEntity<>(categoria1, HttpStatus.OK);
    }

    @DeleteMapping(path="/{id}")
    ResponseEntity<Object> delete(@PathVariable Integer id) {
        String message = "La categoria con id "+id+" è stata cancellata con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        categoriaService.deleteById(id);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

    @PutMapping(path = "/{id}")
    ResponseEntity<Categoria> update(@PathVariable Integer id, @RequestBody Categoria categoria) {
        Categoria updatedCategoria = categoriaService.update(id, categoria);
        if (updatedCategoria != null) {
            return new ResponseEntity<>(updatedCategoria, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping(path ="/")
    ResponseEntity<?> deleteAll(){
        categoriaService.deleteAll();
        String message = "Tutte le categorie sono state cancellate con successo!"; 
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }
}
