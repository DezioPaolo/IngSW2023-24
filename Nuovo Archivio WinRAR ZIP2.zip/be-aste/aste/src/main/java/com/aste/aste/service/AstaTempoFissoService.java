package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.AstaTempoFisso;
import com.aste.aste.repository.AstaTempoFissoRepository;

@Service
public class AstaTempoFissoService {
    @Autowired
    AstaTempoFissoRepository astaTempoFissoRepository;

    
     public List<AstaTempoFisso> findAll(){
        return astaTempoFissoRepository.findAll();
    }
    
    public AstaTempoFisso findById(Integer id){
        return astaTempoFissoRepository.findById(id).orElse(null);
    }

    public AstaTempoFisso save(AstaTempoFisso astaTempoFisso){
        return astaTempoFissoRepository.save(astaTempoFisso);
    }

    public void deleteById(Integer id){
        astaTempoFissoRepository.deleteById(id);
    }

    public AstaTempoFisso update(Integer id, AstaTempoFisso astaTempoFisso){
        AstaTempoFisso astaTempoFisso1 = astaTempoFissoRepository.findById(id).orElse(null);
        if (astaTempoFisso1 != null){
            astaTempoFisso1.setTitolo(astaTempoFisso.getTitolo());
            astaTempoFisso1.setDescrizione(astaTempoFisso.getDescrizione());
            astaTempoFisso1.setFotografia(astaTempoFisso.getFotografia());
            astaTempoFisso1.setIdcategoria(astaTempoFisso.getIdcategoria());
            astaTempoFisso1.setDatascadenza(astaTempoFisso.getDatascadenza());
            astaTempoFisso1.setSogliaminima(astaTempoFisso.getSogliaminima());
            astaTempoFisso1.setStato(astaTempoFisso.getStato());
            astaTempoFisso1.setIdvenditore(astaTempoFisso.getIdvenditore());
            astaTempoFisso1.setIdofferta(astaTempoFisso.getIdvenditore());
            return astaTempoFissoRepository.save(astaTempoFisso1);
        }
        return null;
    }
    
    public void deleteAll(){
        astaTempoFissoRepository.deleteAll();
    }
}