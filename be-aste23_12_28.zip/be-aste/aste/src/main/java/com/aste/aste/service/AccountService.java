package com.aste.aste.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.Account;
import com.aste.aste.repository.AccountRepository;

@Service
public class AccountService {
    @Autowired
    AccountRepository accountRepository;

    public List<Account> findAll(){
        return accountRepository.findAll(); 
    }
    
    
    public Account findById(Integer id){
        return accountRepository.findById(id).orElse(null);
    }

    
    public Account save(Account account){
        return accountRepository.save(account);
    }


    public void deleteById(Integer id){
        accountRepository.deleteById(id);
    }


    public Account update(Integer id, Account account){
        Account account1 = accountRepository.findById(id).orElse(null);
        if (account1 != null){
            account1.setTipologia(account.getTipologia());
            account1.setEmail(account.getEmail());
            account1.setPassword(account.getPassword());
            account1.setFotografia(account.getFotografia());
            account1.setNome(account.getNome());
            account1.setCognome(account.getCognome());
            account1.setDatanascita(account.getDatanascita());
            account1.setIndirizzo(account.getIndirizzo());
            account1.setBiografia(account.getBiografia());
            account1.setSitoweb(account.getSitoweb());
            account1.setInstagram(account.getInstagram());
            account1.setFacebook(account.getFacebook());
            account1.setTwitter(account.getTwitter());
            account1.setTiktok(account.getTiktok());
            return accountRepository.save(account1);
        }
        return null;
    }

    public void deleteAll(){
        accountRepository.deleteAll();
    }

    
    public List<String> getAllEmails() {
        List<Account> allAccounts = accountRepository.findAll();
        return allAccounts.stream()
                .map(Account::getEmail)
                .collect(Collectors.toList());
    }

    public Optional<Account> login(String email, String password) {
        return accountRepository.findByEmailAndPassword(email, password);
    }
}
