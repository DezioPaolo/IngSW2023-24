package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.AstaInversa;
import com.aste.aste.repository.AstaInversaRepository;

@Service
public class AstaInversaService {
    @Autowired
    AstaInversaRepository astaInversaRepository;

    public List<AstaInversa> findAll(){
        return astaInversaRepository.findAll();
    }

    public AstaInversa findById(Integer id){
        return astaInversaRepository.findById(id).orElse(null);
    }

    public AstaInversa save(AstaInversa astaInversa){
        return astaInversaRepository.save(astaInversa);
    }

    public void deleteById(Integer id){
        astaInversaRepository.deleteById(id);
    }

     public AstaInversa update(Integer id, AstaInversa astaInversa){
        AstaInversa astaInversa1 = astaInversaRepository.findById(id).orElse(null);
        if (astaInversa1 != null){
            astaInversa1.setTitolo(astaInversa.getTitolo());
            astaInversa1.setDescrizione(astaInversa.getDescrizione());
            astaInversa1.setFotografia(astaInversa.getFotografia());
            astaInversa1.setIdcategoria(astaInversa.getIdcategoria());
            astaInversa1.setPrezzoiniziale(astaInversa.getPrezzoiniziale());
            astaInversa1.setDatascadenza(astaInversa.getDatascadenza());
            astaInversa1.setIdcompratore(astaInversa.getIdcompratore());
            astaInversa1.setStato(astaInversa.getStato());
            astaInversa1.setIdofferta(astaInversa.getIdofferta());
            return astaInversaRepository.save(astaInversa1);
        }
        return null;
    }

    public void deleteAll(){
        astaInversaRepository.deleteAll();
    }

}
