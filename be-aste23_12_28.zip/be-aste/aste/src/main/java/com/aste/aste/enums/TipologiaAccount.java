package com.aste.aste.enums;

public enum TipologiaAccount {
    VENDITORE,
    COMPRATORE,
    ADMIN
}
