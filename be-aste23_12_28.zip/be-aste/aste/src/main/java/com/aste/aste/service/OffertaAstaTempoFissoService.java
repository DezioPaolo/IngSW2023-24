package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.OffertaAstaTempoFisso;
import com.aste.aste.repository.OffertaAstaTempoFissoRepository;

@Service
public class OffertaAstaTempoFissoService {
    @Autowired
    OffertaAstaTempoFissoRepository offertaAstaTempoFissoRepository;

    public List<OffertaAstaTempoFisso> findAll(){
        return offertaAstaTempoFissoRepository.findAll();
    }
    
    public OffertaAstaTempoFisso findById(Integer id){
        return offertaAstaTempoFissoRepository.findById(id).orElse(null);
    }

    public OffertaAstaTempoFisso save(OffertaAstaTempoFisso offertaAstaTempoFisso){
        return offertaAstaTempoFissoRepository.save(offertaAstaTempoFisso);
    }

    public void deleteById(Integer id){
        offertaAstaTempoFissoRepository.deleteById(id);
    }

    public OffertaAstaTempoFisso update(Integer id, OffertaAstaTempoFisso offertaAstaTempoFisso){
        OffertaAstaTempoFisso offertaAstaTempoFisso1 = offertaAstaTempoFissoRepository.findById(id).orElse(null);
        if(offertaAstaTempoFisso1 != null){
       
            offertaAstaTempoFisso1.setIdcompratore(offertaAstaTempoFisso.getIdcompratore());
            offertaAstaTempoFisso1.setIdasta(offertaAstaTempoFisso.getIdasta());
            offertaAstaTempoFisso1.setOfferta(offertaAstaTempoFisso.getOfferta());
            
            return offertaAstaTempoFissoRepository.save(offertaAstaTempoFisso1);
        }
        return null;
    }
    public void deleteAll(){
        offertaAstaTempoFissoRepository.deleteAll();
    }
}
