package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.OffertaAstaInversa;
import com.aste.aste.repository.OffertaAstaInversaRepository;

@Service
public class OffertaAstaInversaService {
    @Autowired
    OffertaAstaInversaRepository offertaAstaInversaRepository;

    public List<OffertaAstaInversa> findAll(){
        return offertaAstaInversaRepository.findAll();
    }
    
    public OffertaAstaInversa findById(Integer id){
        return offertaAstaInversaRepository.findById(id).orElse(null);
    }

    public OffertaAstaInversa save(OffertaAstaInversa offertaAstaInversa){
        return offertaAstaInversaRepository.save(offertaAstaInversa);
    }

    public void deleteById(Integer id){
        offertaAstaInversaRepository.deleteById(id);
    }
    
    public OffertaAstaInversa update(Integer id, OffertaAstaInversa offertaAstaInversa){
        OffertaAstaInversa offertaAstaInversa1 = offertaAstaInversaRepository.findById(id).orElse(null);
        if(offertaAstaInversa1 != null){
            offertaAstaInversa1.setIdvenditore(offertaAstaInversa.getIdvenditore());
            offertaAstaInversa1.setIdasta(offertaAstaInversa.getIdasta());
            offertaAstaInversa1.setOfferta(offertaAstaInversa.getOfferta());
            return offertaAstaInversaRepository.save(offertaAstaInversa1);
        }
        return null;
    }
    
    public void deleteAll(){
        offertaAstaInversaRepository.deleteAll();
    }
   
}
