package com.aste.aste.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aste.aste.domain.Account;
import com.aste.aste.service.AccountService;


@RestController
@RequestMapping("/DietiDials24/management/account")
public class AccountController {
    @Autowired
    AccountService accountService;

    //RICHIESTE GET
    @GetMapping(path = "/")
    ResponseEntity<?> findAll() {
        return new ResponseEntity<>(accountService.findAll(), HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    ResponseEntity<Account> findById(@PathVariable Integer id) {
        Account account = accountService.findById(id);
        return new ResponseEntity<Account>(account, HttpStatus.OK);
    }

    
    @GetMapping("/all-emails")
    public ResponseEntity<List<String>> getAllEmails() {
        List<String> emails = accountService.getAllEmails();
        return ResponseEntity.ok(emails);
    }

    //RICHIESTE POST
    @PostMapping
    ResponseEntity<Account> save(@RequestBody Account account) {
        Account account1 = accountService.save(account);
        return new ResponseEntity<>(account1, HttpStatus.OK);
    }

    //RICHIESTE PUT
    @PutMapping(path = "/{id}")
    ResponseEntity<Account> update(@PathVariable Integer id, @RequestBody Account account) {
        Account updatedAccount = accountService.update(id, account);
        if (updatedAccount != null) {
            return new ResponseEntity<>(updatedAccount, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    //RICHIESTE DELETE
    @DeleteMapping(path="/")
    ResponseEntity<?>deleteAll(){
        accountService.deleteAll();
        String message = "Tutti gli account sono stati cancellati con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

     @DeleteMapping(path="/{id}")
    ResponseEntity<Object> delete(@PathVariable Integer id) {
        String message = "L'account con id "+id+" è stato cancellato con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        accountService.deleteById(id);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }


    

    

}
