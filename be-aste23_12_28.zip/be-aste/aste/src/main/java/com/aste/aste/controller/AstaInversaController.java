package com.aste.aste.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aste.aste.domain.AstaInversa;
import com.aste.aste.service.AstaInversaService;

@RestController
@RequestMapping("/DietiDials24/AstaInversa")
public class AstaInversaController {
    @Autowired
    AstaInversaService astaInversaService;

    @GetMapping(path = "/")
    ResponseEntity<?> findPippo() {
        return new ResponseEntity<>(astaInversaService.findAll(), HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    ResponseEntity<AstaInversa> findById(@PathVariable Integer id) {
        AstaInversa astaInversa = astaInversaService.findById(id);
        return new ResponseEntity<AstaInversa>(astaInversa, HttpStatus.OK);
    }

    @PostMapping
    ResponseEntity<AstaInversa> save(@RequestBody AstaInversa astaInversa) {
        AstaInversa astaInversa1 = astaInversaService.save(astaInversa);
        return new ResponseEntity<>(astaInversa1, HttpStatus.OK);
    }

    @DeleteMapping(path="/{id}")
    ResponseEntity<Object> delete(@PathVariable Integer id) {
        String message = "L'asta inversa con id "+id+" è stato cancellato con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        astaInversaService.deleteById(id);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

    @PutMapping(path = "/{id}")
    ResponseEntity<AstaInversa> update(@PathVariable Integer id, @RequestBody AstaInversa astaInversa) {
        AstaInversa updatedAstaInversa = astaInversaService.update(id, astaInversa);
        if (updatedAstaInversa != null) {
            return new ResponseEntity<>(updatedAstaInversa, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping(path ="/")
    ResponseEntity<?> deleteAll(){
        astaInversaService.deleteAll();
        String message = "Tutte le aste inverse sono state cancellate con successo!"; 
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

}