package com.aste.aste.domain;

import java.sql.Date;

import com.aste.aste.enums.TipologiaAccount;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="ACCOUNT")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Enumerated(EnumType.STRING)
    private TipologiaAccount tipologia;
    private String email;
    private String password;
    private String fotografia;
    private String nome;
    private String cognome;
    private Date datanascita;
    private String indirizzo;
    private String biografia;
    private String sitoweb;
    private String instagram;
    private String facebook;
    private String twitter;
    private String tiktok;
}
