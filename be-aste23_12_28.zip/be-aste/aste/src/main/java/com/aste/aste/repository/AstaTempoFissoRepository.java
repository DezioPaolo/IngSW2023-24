package com.aste.aste.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aste.aste.domain.AstaTempoFisso;
import com.aste.aste.enums.StatoAsta;

@Repository
public interface AstaTempoFissoRepository extends JpaRepository<AstaTempoFisso,Integer>{
    
    @Query("SELECT a FROM AstaTempoFisso a WHERE a.datascadenza < :currentDate AND a.stato = :stato")
    List<AstaTempoFisso> findByDatascadenzaBeforeAndStato(
        @Param("currentDate") Date currentDate, 
        @Param("stato") StatoAsta stato
    );
}
