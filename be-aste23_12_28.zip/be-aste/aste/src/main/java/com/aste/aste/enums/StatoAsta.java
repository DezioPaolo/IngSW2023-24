package com.aste.aste.enums;

public enum StatoAsta {
    CONCLUSA,
    FALLITA,
    IN_CORSO
}
