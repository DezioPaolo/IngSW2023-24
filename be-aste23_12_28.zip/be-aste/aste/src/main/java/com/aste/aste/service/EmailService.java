package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
    @Autowired
    private JavaMailSender javaMailSender;

    public void sendEmails(List<String> emailList, String oggetto, String message) {
        for (String email : emailList) {
            sendEmail(email, oggetto, message);
        }
    }

    private void sendEmail(String email, String oggetto, String message) {
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(email);
        mailMessage.setSubject(oggetto);
        mailMessage.setText(message);

        javaMailSender.send(mailMessage);
    }
}
