package com.aste.aste.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aste.aste.domain.OffertaAstaTempoFisso;
import com.aste.aste.service.OffertaAstaTempoFissoService;

@RestController
@RequestMapping("/DietiDials24/AstaTempoFisso/Offerte")
public class OffertaAstaTempoFissoController {
    @Autowired
    OffertaAstaTempoFissoService offertaAstaTempoFissoService;
    
    @GetMapping(path = "/")
    ResponseEntity<?> findAll() {
        return new ResponseEntity<>(offertaAstaTempoFissoService.findAll(), HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    ResponseEntity<OffertaAstaTempoFisso> findById(@PathVariable Integer id) {
        OffertaAstaTempoFisso offertaAstaTempoFisso = offertaAstaTempoFissoService.findById(id);
        return new ResponseEntity<OffertaAstaTempoFisso>(offertaAstaTempoFisso, HttpStatus.OK);
    }

    @PostMapping
    ResponseEntity<OffertaAstaTempoFisso> save(@RequestBody OffertaAstaTempoFisso offertaAstaTempoFisso) {
        OffertaAstaTempoFisso offertaAstaTempoFisso1 = offertaAstaTempoFissoService.save(offertaAstaTempoFisso);
        return new ResponseEntity<>(offertaAstaTempoFisso1, HttpStatus.OK);
    }

    @DeleteMapping(path="/{id}")
    ResponseEntity<Object> delete(@PathVariable Integer id) {
        String message = "L'offerta per l'asta a tempo fisso con id "+id+" è stato cancellato con successo!";
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        offertaAstaTempoFissoService.deleteById(id);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }

    @PutMapping(path = "/{id}")
    ResponseEntity<OffertaAstaTempoFisso> update(@PathVariable Integer id, @RequestBody OffertaAstaTempoFisso offertaAstaTempoFisso) {
        OffertaAstaTempoFisso updatedOffertaAstaTempoFisso = offertaAstaTempoFissoService.update(id, offertaAstaTempoFisso);
        if (updatedOffertaAstaTempoFisso != null) {
            return new ResponseEntity<>(updatedOffertaAstaTempoFisso, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping(path ="/")
    ResponseEntity<?> deleteAll(){
        offertaAstaTempoFissoService.deleteAll();
        String message = "Tutte le offerte delle aste a tempo fisso sono state cancellate con successo!"; 
        Map<String, String> deleteMessage = new HashMap<>();
        deleteMessage.put("message", message);
        return new ResponseEntity<>(deleteMessage, HttpStatus.OK);
    }
}
