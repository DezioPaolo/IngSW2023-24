package com.aste.aste.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aste.aste.domain.OffertaAstaRibasso;
import com.aste.aste.repository.OffertaAstaRibassoRepository;

@Service
public class OffertaAstaRibassoService {
    @Autowired
    OffertaAstaRibassoRepository offertaAstaRibassoRepository;

    public List<OffertaAstaRibasso> findAll(){
        return offertaAstaRibassoRepository.findAll();
    }
    
    public OffertaAstaRibasso findById(Integer id){
        return offertaAstaRibassoRepository.findById(id).orElse(null);
    }

    public OffertaAstaRibasso save(OffertaAstaRibasso offertaAstaRibasso){
        return offertaAstaRibassoRepository.save(offertaAstaRibasso);
    }

    public void deleteById(Integer id){
        offertaAstaRibassoRepository.deleteById(id);
    }

     public OffertaAstaRibasso update(Integer id, OffertaAstaRibasso offertaAstaRibasso){
        OffertaAstaRibasso offertaAstaRibasso1 = offertaAstaRibassoRepository.findById(id).orElse(null);
        if(offertaAstaRibasso1 != null){
            offertaAstaRibasso1.setIdcompratore(offertaAstaRibasso.getIdcompratore());
            offertaAstaRibasso1.setIdasta(offertaAstaRibasso.getIdasta());
            
            return offertaAstaRibassoRepository.save(offertaAstaRibasso1);
        }
        return null;
    }
    
    public void deleteAll(){
        offertaAstaRibassoRepository.deleteAll();
    }
}
